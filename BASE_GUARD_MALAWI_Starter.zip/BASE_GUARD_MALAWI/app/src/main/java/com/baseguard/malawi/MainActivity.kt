package com.baseguard.malawi

import android.Manifest
import android.content.Intent
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF101B35)
private val Red = Color(0xFFD62828)
private val Pale = Color(0xFFF3F5F9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BaseGuardApp() }
    }
}

@Composable
fun BaseGuardApp() {
    var tab by remember { mutableStateOf(0) }
    var latitude by remember { mutableStateOf("Not available") }
    var longitude by remember { mutableStateOf("Not available") }
    var showSosConfirm by remember { mutableStateOf(false) }
    var sosMessage by remember { mutableStateOf("") }
    var reportText by remember { mutableStateOf("") }
    var reportType by remember { mutableStateOf("Accident") }
    var reportSaved by remember { mutableStateOf(false) }
    var contactName by remember { mutableStateOf("") }
    var contactPhone by remember { mutableStateOf("") }
    val prefs = remember { context.getSharedPreferences("base_guard_local", android.content.Context.MODE_PRIVATE) }
    val contacts = remember {
        mutableStateListOf<Pair<String, String>>().apply {
            val raw = prefs.getString("contacts", "[]") ?: "[]"
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    add(item.optString("name") to item.optString("phone"))
                }
            } catch (_: Exception) { }
        }
    }
    val reports = remember {
        mutableStateListOf<String>().apply {
            val raw = prefs.getString("reports", "[]") ?: "[]"
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) add(arr.optString(i))
            } catch (_: Exception) { }
        }
    }
    fun saveContacts() {
        val arr = JSONArray()
        contacts.forEach { (name, phone) ->
            arr.put(JSONObject().put("name", name).put("phone", phone))
        }
        prefs.edit().putString("contacts", arr.toString()).apply()
    }
    fun saveReports() {
        val arr = JSONArray()
        reports.forEach { arr.put(it) }
        prefs.edit().putString("reports", arr.toString()).apply()
    }
    val locationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            val lm = context.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
            val provider = if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
            try {
                @Suppress("MissingPermission")
                val loc: Location? = lm.getLastKnownLocation(provider)
                if (loc != null) {
                    latitude = loc.latitude.toString()
                    longitude = loc.longitude.toString()
                } else {
                    latitude = "No recent fix — enable GPS outdoors"
                }
            } catch (_: Exception) {
                latitude = "Location unavailable"
            }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Navy, secondary = Red, background = Pale, surface = Color.White
    )) {
        Scaffold(
            topBar = {
                Column(Modifier.fillMaxWidth().background(Navy).padding(18.dp)) {
                    Text("BASE GUARD MALAWI", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                    Text("National Emergency & Safety Platform • Malawi", color = Color(0xFFDCE4F5), style = MaterialTheme.typography.bodySmall)
                }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Report, null) }, label = { Text("Report") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Contacts, null) }, label = { Text("Contacts") })
                }
            },
            containerColor = Pale
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                when (tab) {
                    0 -> LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("NEED EMERGENCY HELP?", fontWeight = FontWeight.Bold, color = Navy)
                                    Spacer(Modifier.height(14.dp))
                                    Button(
                                        onClick = { showSosConfirm = true },
                                        modifier = Modifier.size(190.dp),
                                        shape = CircleShape,
                                        colors = ButtonDefaults.buttonColors(containerColor = Red)
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Default.Warning, null, modifier = Modifier.size(42.dp), tint = Color.White)
                                            Text("SOS", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black, color = Color.White)
                                            Text("EMERGENCY", color = Color.White)
                                        }
                                    }
                                    Spacer(Modifier.height(12.dp))
                                    Text("Press only when you need urgent assistance.", color = Color.Gray)
                                    if (sosMessage.isNotBlank()) Text(sosMessage, color = Red, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                        item {
                            Card(shape = RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("MY GPS LOCATION", fontWeight = FontWeight.Bold, color = Navy)
                                    Text("Latitude: $latitude")
                                    Text("Longitude: $longitude")
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedButton(onClick = {
                                        locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                                    }) { Icon(Icons.Default.MyLocation, null); Spacer(Modifier.width(8.dp)); Text("Get my location") }
                                }
                            }
                        }
                        item {
                            Card(shape = RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("QUICK ACCESS", fontWeight = FontWeight.Bold, color = Navy)
                                    Text("Report an incident or manage your trusted emergency contacts using the tabs below.")
                                }
                            }
                        }
                    }
                    1 -> LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Text("REPORT AN INCIDENT", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Navy)
                            Text("Describe an emergency, accident, fire or crime.")
                            Spacer(Modifier.height(8.dp))
                            var expanded by remember { mutableStateOf(false) }
                            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                                OutlinedTextField(value = reportType, onValueChange = {}, readOnly = true, label = { Text("Incident type") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    listOf("Accident", "Fire", "Crime", "Medical emergency", "Other").forEach {
                                        DropdownMenuItem(text = { Text(it) }, onClick = { reportType = it; expanded = false })
                                    }
                                }
                            }
                            OutlinedTextField(value = reportText, onValueChange = { reportText = it }, label = { Text("What happened?") }, minLines = 4, modifier = Modifier.fillMaxWidth())
                            Button(onClick = {
                                if (reportText.isNotBlank()) {
                                    reports.add(0, "$reportType • $reportText")
                                    saveReports()
                                    reportText = ""; reportSaved = true
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Send, null); Spacer(Modifier.width(8.dp)); Text("Save report on this device") }
                            if (reportSaved) Text("Report saved locally on this device. It has NOT been sent to emergency services.", color = Red)
                            Divider()
                            Text("Saved reports", fontWeight = FontWeight.Bold)
                        }
                        items(reports) { Text("• $it", modifier = Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(10.dp)).padding(12.dp)) }
                    }
                    else -> LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Text("EMERGENCY CONTACTS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Navy)
                            Text("Add up to 3 trusted people.")
                            OutlinedTextField(value = contactName, onValueChange = { contactName = it }, label = { Text("Contact name") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(value = contactPhone, onValueChange = { contactPhone = it }, label = { Text("Phone number") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = {
                                if (contactName.isNotBlank() && contactPhone.isNotBlank() && contacts.size < 3) {
                                    contacts.add(contactName.trim() to contactPhone.trim())
                                    saveContacts()
                                    contactName = ""; contactPhone = ""
                                }
                            }, enabled = contacts.size < 3, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PersonAdd, null); Spacer(Modifier.width(8.dp)); Text("Add contact") }
                            if (contacts.size >= 3) Text("Maximum of 3 contacts reached.")
                            Divider()
                        }
                        items(contacts) { c ->
                            Card {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Person, null, tint = Navy)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) { Text(c.first, fontWeight = FontWeight.Bold); Text(c.second) }
                                    IconButton(onClick = { contacts.remove(c); saveContacts() }) { Icon(Icons.Default.Delete, null, tint = Red) }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (showSosConfirm) {
            AlertDialog(
                onDismissRequest = { showSosConfirm = false },
                title = { Text("Confirm emergency SOS?") },
                text = { Text("This opens your SMS app with a message addressed to your saved emergency contacts. Check the message and press Send yourself. It does NOT automatically contact Police, Fire, Ambulance or hospitals.") },
                confirmButton = {
                    TextButton(onClick = {
                        val stamp = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date())
                        val message = "BASE GUARD SOS TEST/REQUEST: I may need emergency assistance. " +
                            "Time: $stamp. GPS: $latitude, $longitude. Please contact me and verify my safety."
                        val recipients = contacts.joinToString(";") { it.second }
                        if (recipients.isNotBlank()) {
                            try {
                                val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
                                    data = Uri.parse("smsto:$recipients")
                                    putExtra("sms_body", message)
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(smsIntent)
                                sosMessage = "SMS draft opened. Review and press Send in your messaging app."
                            } catch (_: Exception) {
                                sosMessage = "Could not open SMS app. No alert was sent."
                            }
                        } else {
                            sosMessage = "No emergency contacts saved. No alert was sent."
                        }
                        showSosConfirm = false
                    }) { Text("Open SMS draft", color = Red) }
                },
                dismissButton = { TextButton(onClick = { showSosConfirm = false }) { Text("Cancel") } }
            )
        }
    }
}
