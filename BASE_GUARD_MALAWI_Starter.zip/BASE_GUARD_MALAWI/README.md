# BASE GUARD MALAWI — Android MVP starter

Android Studio source project for the BASE GUARD MVP described in the supplied proposal.

## Included
- Home screen with SOS confirmation
- Requests location permission and reads the last-known GPS/network location
- SOS opens the phone's SMS app with a prefilled message to up to three saved emergency contacts; the user must review and press Send
- Incident reports saved locally on the device
- Up to three emergency contacts saved locally on the device
- Basic local persistence using Android SharedPreferences

## Important limitations
This is an early prototype, not a live emergency dispatch system. It does **not** automatically notify Police, Fire, Ambulance, hospitals, or a government control room. It does not include a backend/cloud database, SMS gateway account, admin dashboard, authentication, agency dispatch, or production security. Location is last-known location and may be stale or unavailable. SMS requires a working SIM/network and may incur carrier charges. Reports and contacts are stored on this device only.

Do not use this prototype as a substitute for contacting local emergency services.

## Build an APK
1. Install Android Studio on a computer and install Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to download the Android Gradle Plugin and dependencies.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location.

The current execution environment has no Android SDK or Gradle, so an APK cannot be compiled here. This archive contains the source project to build in Android Studio.


## Build from a phone using GitHub Actions
1. Create/sign in to a GitHub account in your phone browser.
2. Create a new repository named `base-guard`.
3. Upload the contents of this ZIP into the repository (including the hidden `.github` folder).
4. Open the repository's **Actions** tab and allow workflows if GitHub asks.
5. Run **Build BASE GUARD APK** (or wait for the first push workflow).
6. Open the completed workflow run, scroll to **Artifacts**, and download `base-guard-debug-apk`.
7. Extract the artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from that browser/files app.

The APK produced by this workflow is a debug/test build, not a Play Store release.
